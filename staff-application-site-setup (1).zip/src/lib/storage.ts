import { User, Application, SiteSettings } from '../types';

const STORAGE_KEYS = {
  USERS: 'capyworld_users',
  APPLICATIONS: 'capyworld_applications',
  SETTINGS: 'capyworld_settings',
  CURRENT_USER: 'capyworld_current_user',
  BLACKLIST: 'capyworld_blacklist',
};

// NOTE: localStorage acts as the persistent database for this application.
// Data will persist on the user's device even after closing the browser.


// Initial settings
const defaultSettings: SiteSettings = {
  openRoles: ['builder', 'designer', 'admin', 'event-manager', 'tester', 'curator', 'developer', 'content-maker', 'streamer', 'promoter'],
};

// Helpers
const getStorage = <T>(key: string, defaultValue: T): T => {
  const stored = localStorage.getItem(key);
  if (!stored) return defaultValue;
  try {
    return JSON.parse(stored);
  } catch {
    return defaultValue;
  }
};

const setStorage = <T>(key: string, value: T) => {
  localStorage.setItem(key, JSON.stringify(value));
};

// User Operations
export const storage = {
  getUsers: (): User[] => getStorage<User[]>(STORAGE_KEYS.USERS, []),
  
  createUser: (username: string, password?: string, role: 'user' | 'admin' = 'user'): User => {
    const users = storage.getUsers();
    if (users.find(u => u.username === username)) {
      throw new Error('Пользователь с таким именем уже существует');
    }
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      username,
      password, // In a real app, hash this!
      role,
    };
    setStorage(STORAGE_KEYS.USERS, [...users, newUser]);
    return newUser;
  },

  login: (username: string, password?: string): User => {
    const users = storage.getUsers();
    const user = users.find(u => u.username === username);
    
    if (!user) throw new Error('Пользователь не найден');
    
    // Check password if it exists on the user record (backward compatibility or new requirement)
    if (user.password && user.password !== password) {
      throw new Error('Неверный пароль');
    }
    
    storage.setCurrentUser(user);
    return user;
  },

  getCurrentUser: (): User | null => getStorage<User | null>(STORAGE_KEYS.CURRENT_USER, null),
  
  setCurrentUser: (user: User | null) => setStorage(STORAGE_KEYS.CURRENT_USER, user),

  logout: () => setStorage(STORAGE_KEYS.CURRENT_USER, null),

  // Application Operations
  getApplications: (): Application[] => getStorage<Application[]>(STORAGE_KEYS.APPLICATIONS, []),

  createApplication: (appData: Omit<Application, 'id' | 'status' | 'createdAt' | 'messages'>) => {
    const apps = storage.getApplications();
    const newApp: Application = {
      ...appData,
      id: Math.random().toString(36).substr(2, 9),
      status: 'pending',
      createdAt: Date.now(),
      messages: [],
    };
    setStorage(STORAGE_KEYS.APPLICATIONS, [...apps, newApp]);
    return newApp;
  },

  updateApplicationStatus: (id: string, status: 'approved' | 'rejected' | 'interview') => {
    const apps = storage.getApplications();
    const updatedApps = apps.map(app => 
      app.id === id ? { ...app, status } : app
    );
    setStorage(STORAGE_KEYS.APPLICATIONS, updatedApps);
  },

  addMessageToApplication: (appId: string, message: Omit<import('../types').ChatMessage, 'id' | 'timestamp'>) => {
    const apps = storage.getApplications();
    const updatedApps = apps.map(app => {
      if (app.id === appId) {
        const newMessage: import('../types').ChatMessage = {
          ...message,
          id: Math.random().toString(36).substr(2, 9),
          timestamp: Date.now(),
        };
        return { ...app, messages: [...app.messages, newMessage] };
      }
      return app;
    });
    setStorage(STORAGE_KEYS.APPLICATIONS, updatedApps);
  },

  // Settings Operations
  getSettings: (): SiteSettings => getStorage<SiteSettings>(STORAGE_KEYS.SETTINGS, defaultSettings),

  toggleRoleStatus: (roleId: string) => {
    const settings = storage.getSettings();
    const isOpen = settings.openRoles.includes(roleId);
    let newOpenRoles;
    
    if (isOpen) {
      newOpenRoles = settings.openRoles.filter(id => id !== roleId);
    } else {
      newOpenRoles = [...settings.openRoles, roleId];
    }
    
    setStorage(STORAGE_KEYS.SETTINGS, { ...settings, openRoles: newOpenRoles });
    return newOpenRoles;
  },
  
  getTeamSize: (): number => {
      // Calculate team size based on number of admins
      const users = storage.getUsers();
      return users.filter(u => u.role === 'admin').length;
  },

  // Blacklist Operations
  getBlacklist: (): import('../types').BlacklistEntry[] => getStorage<import('../types').BlacklistEntry[]>(STORAGE_KEYS.BLACKLIST, []),

  addToBlacklist: (entry: Omit<import('../types').BlacklistEntry, 'id' | 'createdAt'>) => {
    const list = storage.getBlacklist();
    // Check if already blacklisted for same type
    if (list.some(item => item.username.toLowerCase() === entry.username.toLowerCase() && item.type === entry.type)) {
        throw new Error(`Пользователь ${entry.username} уже находится в ЧС (${entry.type})`);
    }

    const newEntry: import('../types').BlacklistEntry = {
      ...entry,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: Date.now(),
    };
    setStorage(STORAGE_KEYS.BLACKLIST, [...list, newEntry]);
    return newEntry;
  },

  removeFromBlacklist: (username: string, type: import('../types').BlacklistType) => {
    const list = storage.getBlacklist();
    const filtered = list.filter(item => !(item.username.toLowerCase() === username.toLowerCase() && item.type === type));
    if (list.length === filtered.length) {
        throw new Error('Запись в ЧС не найдена');
    }
    setStorage(STORAGE_KEYS.BLACKLIST, filtered);
  }
};
