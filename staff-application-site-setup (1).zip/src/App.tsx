import { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { RoleCard } from './components/RoleCard';
import { ApplicationForm } from './components/ApplicationForm';
import { Auth } from './components/Auth';
import { AdminPanel } from './components/AdminPanel';
import { TicketChat } from './components/TicketChat';
import { roles } from './data/roles';
import { motion, AnimatePresence } from 'framer-motion';
import { storage } from './lib/storage';
import { User, Application } from './types';
import { MessageSquare, Clock, CheckCircle, XCircle } from 'lucide-react';

type View = 'auth' | 'home' | 'apply' | 'admin' | 'ticket';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState<View>('auth');
  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);
  const [openRoles, setOpenRoles] = useState<string[]>([]);
  const [userApplication, setUserApplication] = useState<Application | null>(null);

  const refreshUserData = () => {
     const currentUser = storage.getCurrentUser();
     if (currentUser) {
        setUser(currentUser);
        // Find user's latest application
        const apps = storage.getApplications();
        const myApp = apps.find(a => a.userId === currentUser.id);
        setUserApplication(myApp || null);
     }
  };

  useEffect(() => {
    refreshUserData();
    setOpenRoles(storage.getSettings().openRoles);

    // Polling for updates (messages, status changes)
    const interval = setInterval(() => {
        refreshUserData();
        setOpenRoles(storage.getSettings().openRoles);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    setView('home');
    refreshUserData();
  };

  const handleLogout = () => {
    storage.logout();
    setUser(null);
    setView('auth');
    setSelectedRoleId(null);
    setUserApplication(null);
  };

  const handleRoleSelect = (id: string) => {
    if (!user) return;

    const blacklist = storage.getBlacklist();
    const userBan = blacklist.find(b => b.username.toLowerCase() === user.username.toLowerCase());

    if (userBan) {
       if (userBan.type === 'GLOBAL') {
           alert(`Вы находитесь в глобальном черном списке. Причина: ${userBan.reason}`);
           return;
       }
       
       if (userBan.type === 'CSA' && (id === 'admin' || id === 'curator')) {
           alert(`Вы находитесь в ЧС Администрации (CSA). Причина: ${userBan.reason}`);
           return;
       }

       if (userBan.type === 'CST' && id === 'tester') {
           alert(`Вы находитесь в ЧС Тестеров (CST). Причина: ${userBan.reason}`);
           return;
       }

       if (userBan.type === 'CSB' && id === 'builder') {
           alert(`Вы находитесь в ЧС Билдеров (CSB). Причина: ${userBan.reason}`);
           return;
       }
    }

    setSelectedRoleId(id);
    setView('apply');
  };

  const handleBackToHome = () => {
    setSelectedRoleId(null);
    setView('home');
    refreshUserData();
  };

  const handleSendMessage = (text: string) => {
      if (!userApplication || !user) return;
      storage.addMessageToApplication(userApplication.id, {
          senderId: user.id,
          senderName: user.username,
          content: text,
          isAdmin: false
      });
      refreshUserData();
  };

  const selectedRole = roles.find((r) => r.id === selectedRoleId);

  if (!user || view === 'auth') {
    return (
      <Layout 
        user={null} 
        onLogout={() => {}} 
        onAdminClick={() => {}} 
        onHomeClick={() => {}}
      >
        <Auth onLogin={handleLogin} />
      </Layout>
    );
  }

  return (
    <Layout
      user={user}
      onLogout={handleLogout}
      onAdminClick={() => setView('admin')}
      onHomeClick={handleBackToHome}
    >
      <AnimatePresence mode="wait">
        {view === 'home' && (
          <motion.div
            key="home"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-8"
          >
            {/* User Application Status Banner */}
            {userApplication && (
                <div className="rounded-xl border border-slate-800 bg-slate-900 p-6">
                    <h2 className="text-xl font-bold text-white mb-4">Ваша заявка</h2>
                    <div className="flex items-center justify-between flex-wrap gap-4">
                        <div>
                            <p className="text-slate-400 text-sm">Роль: <span className="text-indigo-400 font-medium">{roles.find(r => r.id === userApplication.roleId)?.title}</span></p>
                            <p className="text-slate-400 text-sm">Дата: {new Date(userApplication.createdAt).toLocaleDateString()}</p>
                        </div>
                        
                        <div className="flex items-center gap-4">
                            <div className={`px-4 py-2 rounded-full text-sm font-bold flex items-center gap-2 ${
                                userApplication.status === 'approved' ? 'bg-green-500/10 text-green-500' : 
                                userApplication.status === 'rejected' ? 'bg-red-500/10 text-red-500' :
                                userApplication.status === 'interview' ? 'bg-yellow-500/10 text-yellow-500' :
                                'bg-slate-700 text-slate-300'
                            }`}>
                                {userApplication.status === 'approved' && <CheckCircle size={16} />}
                                {userApplication.status === 'rejected' && <XCircle size={16} />}
                                {userApplication.status === 'interview' && <MessageSquare size={16} />}
                                {userApplication.status === 'pending' && <Clock size={16} />}
                                
                                {userApplication.status === 'approved' ? 'Одобрено' : 
                                userApplication.status === 'rejected' ? 'Отказано' : 
                                userApplication.status === 'interview' ? 'Собеседование' : 'На рассмотрении'}
                            </div>

                            {(userApplication.status === 'interview' || userApplication.messages.length > 0) && (
                                <button 
                                    onClick={() => setView('ticket')}
                                    className="flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-700 transition"
                                >
                                    <MessageSquare size={18} />
                                    Открыть чат
                                    {userApplication.messages.length > 0 && (
                                        <span className="bg-white text-indigo-600 text-xs font-bold px-1.5 rounded-full">
                                            {userApplication.messages.length}
                                        </span>
                                    )}
                                </button>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {!userApplication && (
                <div className="text-center py-8">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                  >
                    <span className="inline-block px-4 py-1.5 mb-4 text-sm font-medium text-indigo-400 bg-indigo-500/10 rounded-full border border-indigo-500/20">
                      Minecraft Survival Server
                    </span>
                    <h1 className="mb-6 text-4xl font-extrabold tracking-tight text-white md:text-6xl bg-clip-text text-transparent bg-gradient-to-b from-white to-slate-400">
                        Присоединяйся к команде
                    </h1>
                    <p className="mx-auto max-w-2xl text-lg text-slate-400 leading-relaxed">
                        Мы ищем талантливых людей, готовых развивать лучший сервер выживания 
                        <span className="text-indigo-400 font-semibold"> CapyWorld</span>. 
                        Станьте частью истории, помогайте игрокам и создавайте уникальный контент вместе с нами!
                    </p>
                  </motion.div>
                </div>
            )}

            {!userApplication && (
                <motion.div 
                  className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
                  variants={{
                    hidden: { opacity: 0 },
                    show: {
                      opacity: 1,
                      transition: {
                        staggerChildren: 0.1
                      }
                    }
                  }}
                  initial="hidden"
                  animate="show"
                >
                {roles
                    .filter(role => !role.isHidden || openRoles.includes(role.id))
                    .map((role) => (
                    <RoleCard
                    key={role.id}
                    {...role}
                    isSelected={selectedRoleId === role.id}
                    onSelect={handleRoleSelect}
                    isOpen={openRoles.includes(role.id)}
                    />
                ))}
                </motion.div>
            )}
          </motion.div>
        )}

        {view === 'apply' && selectedRole && (
          <motion.div
            key="apply"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <div className="mx-auto max-w-3xl">
              <ApplicationForm 
                selectedRoleId={selectedRole.id}
                selectedRoleTitle={selectedRole.title} 
                onBack={handleBackToHome} 
              />
            </div>
          </motion.div>
        )}

        {view === 'ticket' && userApplication && (
             <motion.div
                key="ticket"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="mx-auto max-w-4xl"
            >
                <div className="mb-4">
                    <button 
                        onClick={() => setView('home')} 
                        className="text-slate-400 hover:text-white flex items-center gap-2 mb-4"
                    >
                        ← Назад
                    </button>
                    <TicketChat 
                        title={`Чат с администрацией (${roles.find(r => r.id === userApplication.roleId)?.title})`}
                        messages={userApplication.messages}
                        currentUserId={user.id}
                        onSendMessage={handleSendMessage}
                    />
                </div>
            </motion.div>
        )}

        {view === 'admin' && (
          <motion.div
            key="admin"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
             <AdminPanel onBack={handleBackToHome} />
          </motion.div>
        )}
      </AnimatePresence>
    </Layout>
  );
}

export default App;
