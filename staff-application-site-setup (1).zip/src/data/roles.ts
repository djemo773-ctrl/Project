import { Hammer, Palette, Shield, Calendar, Bug, Crown, Code, Video, Mic, Megaphone, LucideIcon, UserCog, GraduationCap, Briefcase } from 'lucide-react';

export interface Question {
  id: string;
  text: string;
  placeholder?: string;
}

export interface RoleDef {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  color: string;
  questions: Question[];
  isHidden?: boolean;
}

const commonQuestions: Question[] = [
  { id: 'q1', text: 'Как вас зовут? (Реальное имя)', placeholder: 'Иван' },
  { id: 'q2', text: 'Сколько вам лет?', placeholder: '16' },
  { id: 'q3', text: 'Ваш часовой пояс?', placeholder: 'МСК' },
  { id: 'q4', text: 'Сколько времени готовы уделять?', placeholder: '4 часа' },
  { id: 'q5', text: 'Почему именно к нам?', placeholder: '...' },
];

export const roles: RoleDef[] = [
  {
    id: 'curator',
    title: 'Куратор',
    description: 'Управление персоналом и контроль качества.',
    icon: Crown,
    color: 'bg-purple-500',
    questions: [
      ...commonQuestions,
      { id: 'c1', text: 'Ваш опыт управления командой?', placeholder: 'Был админом...' },
      { id: 'c2', text: 'Как вы решаете конфликты?', placeholder: '...' },
    ]
  },
  {
    id: 'deputy-curator',
    title: 'Зам. Куратора',
    description: 'Помощь куратору в управлении персоналом.',
    icon: GraduationCap,
    color: 'bg-purple-400',
    isHidden: true,
    questions: [
        ...commonQuestions,
        { id: 'dc1', text: 'Ваш опыт на руководящих должностях?', placeholder: '...' },
    ]
  },
  {
    id: 'developer',
    title: 'Разработчик',
    description: 'Java/Kotlin разработка.',
    icon: Code,
    color: 'bg-orange-500',
    questions: [
      ...commonQuestions,
      { id: 'd1', text: 'Знание Java/Spigot API?', placeholder: '...' },
      { id: 'd2', text: 'Ссылка на GitHub', placeholder: '...' },
    ]
  },
  {
    id: 'deputy-developer',
    title: 'Зам. Разработчика',
    description: 'Помощь в разработке и техподдержка.',
    icon:  Briefcase,
    color: 'bg-orange-400',
    isHidden: true,
    questions: [
        ...commonQuestions,
        { id: 'dd1', text: 'Ваш опыт в разработке?', placeholder: '...' },
    ]
  },
  {
    id: 'builder',
    title: 'Билдер',
    description: 'Строительство карт и спавнов.',
    icon: Hammer,
    color: 'bg-emerald-500',
    questions: [
      ...commonQuestions,
      { id: 'b1', text: 'Знание WorldEdit/VoxelSniper?', placeholder: '...' },
      { id: 'b2', text: 'Портфолио построек', placeholder: '...' },
    ]
  },
  {
    id: 'designer',
    title: 'Дизайнер',
    description: 'Графический дизайн.',
    icon: Palette,
    color: 'bg-pink-500',
    questions: [
      ...commonQuestions,
      { id: 'ds1', text: 'В каких программах работаете?', placeholder: '...' },
      { id: 'ds2', text: 'Портфолио', placeholder: '...' },
    ]
  },
  {
    id: 'admin',
    title: 'Администрация',
    description: 'Модерация игрового процесса.',
    icon: Shield,
    color: 'bg-red-500',
    questions: [
      ...commonQuestions,
      { id: 'a1', text: 'Знание команд?', placeholder: '...' },
      { id: 'a2', text: 'Как найдете читера?', placeholder: '...' },
    ]
  },
  {
    id: 'event-manager',
    title: 'Ивент-менеджер',
    description: 'Проведение ивентов.',
    icon: Calendar,
    color: 'bg-yellow-500',
    questions: [
      ...commonQuestions,
      { id: 'e1', text: 'Идеи для ивентов?', placeholder: '...' },
    ]
  },
  {
    id: 'tester',
    title: 'Тестер',
    description: 'Поиск багов.',
    icon: Bug,
    color: 'bg-blue-500',
    questions: [
      ...commonQuestions,
      { id: 't1', text: 'Опыт в тестировании?', placeholder: '...' },
    ]
  },
  {
    id: 'content-maker',
    title: 'Контентмейкер',
    description: 'Shorts/TikTok видео.',
    icon: Video,
    color: 'bg-rose-500',
    questions: [
      ...commonQuestions,
      { id: 'cm1', text: 'Ссылка на канал', placeholder: '...' },
    ]
  },
  {
    id: 'streamer',
    title: 'Стример',
    description: 'Стримы на сервере.',
    icon: Mic,
    color: 'bg-violet-500',
    questions: [
      ...commonQuestions,
      { id: 'st1', text: 'Ссылка на канал', placeholder: '...' },
    ]
  },
  {
    id: 'promoter',
    title: 'Промоутер',
    description: 'Реклама сервера.',
    icon: Megaphone,
    color: 'bg-green-600',
    questions: [
      ...commonQuestions,
      { id: 'pr1', text: 'Где будете рекламировать?', placeholder: '...' },
    ]
  },
  {
    id: 'director',
    title: 'Директор',
    description: 'Управление всем проектом. Высшее руководство.',
    icon: UserCog,
    color: 'bg-red-700',
    isHidden: true,
    questions: [
      ...commonQuestions,
      { id: 'dr1', text: 'Ваш опыт управления проектами?', placeholder: '...' },
      { id: 'dr2', text: 'Ваши планы на развитие?', placeholder: '...' },
    ]
  },
  {
    id: 'deputy-director',
    title: 'Зам. Директора',
    description: 'Правая рука директора.',
    icon: UserCog,
    color: 'bg-red-600',
    isHidden: true,
    questions: [
      ...commonQuestions,
      { id: 'ddr1', text: 'Ваш опыт?', placeholder: '...' },
    ]
  },
  {
    id: 'deputy-creator',
    title: 'Зам. Создателя',
    description: 'Второе лицо проекта. Полный контроль.',
    icon: Crown,
    color: 'bg-red-900',
    isHidden: true,
    questions: [
      ...commonQuestions,
      { id: 'dcr1', text: 'Почему мы должны доверить вам сервер?', placeholder: '...' },
    ]
  }
];
