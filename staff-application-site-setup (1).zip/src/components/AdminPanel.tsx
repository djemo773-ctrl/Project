import React, { useState, useEffect } from 'react';
import { storage } from '../lib/storage';
import { Application, SiteSettings, User } from '../types';
import { roles } from '../data/roles';
import { motion } from 'framer-motion';
import { Settings, FileText, ToggleLeft, ToggleRight, ArrowLeft, MessageSquare, Clock, Terminal } from 'lucide-react';
import { TicketChat } from './TicketChat';
import { AdminConsole } from './AdminConsole';

interface AdminPanelProps {
  onBack: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<'applications' | 'settings' | 'console'>('applications');
  const [applications, setApplications] = useState<Application[]>([]);
  const [settings, setSettings] = useState<SiteSettings>(storage.getSettings());
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    refreshData();
    const interval = setInterval(refreshData, 3000); // Polling for chat updates
    setCurrentUser(storage.getCurrentUser());
    return () => clearInterval(interval);
  }, []);

  const refreshData = () => {
    setApplications(storage.getApplications().sort((a, b) => b.createdAt - a.createdAt));
    setSettings(storage.getSettings());
  };

  const handleStatusUpdate = (id: string, status: 'approved' | 'rejected' | 'interview') => {
    storage.updateApplicationStatus(id, status);
    refreshData();
  };

  const handleToggleRole = (roleId: string) => {
    storage.toggleRoleStatus(roleId);
    refreshData();
  };

  const handleSendMessage = (text: string) => {
    if (!selectedAppId || !currentUser) return;
    storage.addMessageToApplication(selectedAppId, {
      senderId: currentUser.id,
      senderName: currentUser.username,
      content: text,
      isAdmin: true,
    });
    refreshData();
  };

  // If detailed view of an application (Chat or Details)
  if (selectedAppId) {
    const app = applications.find(a => a.id === selectedAppId);
    if (!app) {
      setSelectedAppId(null);
      return null;
    }
    const roleDef = roles.find(r => r.id === app.roleId);

    return (
      <div className="space-y-6">
        <button 
          onClick={() => setSelectedAppId(null)}
          className="flex items-center gap-2 rounded-lg bg-slate-800 px-4 py-2 text-slate-300 hover:bg-slate-700 hover:text-white transition-colors"
        >
          <ArrowLeft size={18} />
          Назад к списку
        </button>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Application Details */}
          <div className="rounded-xl bg-slate-900 p-6 border border-slate-800 h-fit">
            <div className="mb-6 flex justify-between items-start">
              <div>
                <h2 className="text-2xl font-bold text-white mb-1">{app.nickname}</h2>
                <div className="text-slate-400 text-sm flex gap-2">
                   <span>{app.discord}</span>
                   <span>•</span>
                   <span>{app.age} лет</span>
                </div>
              </div>
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                 app.status === 'approved' ? 'bg-green-500/10 text-green-500' : 
                 app.status === 'rejected' ? 'bg-red-500/10 text-red-500' :
                 app.status === 'interview' ? 'bg-yellow-500/10 text-yellow-500' :
                 'bg-slate-700 text-slate-300'
              }`}>
                {app.status === 'approved' ? 'Одобрено' : 
                 app.status === 'rejected' ? 'Отказано' : 
                 app.status === 'interview' ? 'Собеседование' : 'На рассмотрении'}
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-3 bg-slate-950 rounded-lg">
                <span className="text-xs font-bold text-slate-500 uppercase">Роль</span>
                <p className="text-indigo-400 font-medium">{roleDef?.title}</p>
              </div>

              {app.portfolio && (
                 <div className="p-3 bg-slate-950 rounded-lg">
                  <span className="text-xs font-bold text-slate-500 uppercase">Портфолио</span>
                  <a href={app.portfolio} target="_blank" rel="noopener noreferrer" className="block text-indigo-400 hover:underline truncate">
                    {app.portfolio}
                  </a>
                </div>
              )}

              <div className="border-t border-slate-800 pt-4">
                <h3 className="text-lg font-bold text-white mb-4">Ответы на вопросы</h3>
                <div className="space-y-4">
                  {roleDef?.questions.map(q => (
                    <div key={q.id}>
                      <p className="text-sm text-slate-500 mb-1">{q.text}</p>
                      <p className="text-slate-200 bg-slate-950 p-3 rounded-lg text-sm whitespace-pre-wrap">
                        {app.answers?.[q.id] || "Нет ответа"}
                      </p>
                    </div>
                  ))}
                  {/* Fallback for legacy data */}
                  {!app.answers && app.about && (
                     <div>
                      <p className="text-sm text-slate-500 mb-1">О себе (Legacy)</p>
                      <p className="text-slate-200 bg-slate-950 p-3 rounded-lg text-sm whitespace-pre-wrap">
                        {app.about}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex gap-2 pt-4 border-t border-slate-800">
                <button
                  onClick={() => handleStatusUpdate(app.id, 'approved')}
                  className="flex-1 py-2 rounded-lg bg-green-600/20 text-green-400 hover:bg-green-600/30 transition font-medium"
                >
                  Одобрить
                </button>
                <button
                  onClick={() => handleStatusUpdate(app.id, 'rejected')}
                  className="flex-1 py-2 rounded-lg bg-red-600/20 text-red-400 hover:bg-red-600/30 transition font-medium"
                >
                  Отказать
                </button>
                {app.status !== 'interview' && (
                  <button
                    onClick={() => handleStatusUpdate(app.id, 'interview')}
                    className="flex-1 py-2 rounded-lg bg-yellow-600/20 text-yellow-400 hover:bg-yellow-600/30 transition font-medium"
                  >
                    Собеседование
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Chat Section */}
          <div className="h-full">
            <TicketChat 
                title={`Чат с кандидатом: ${app.nickname}`}
                messages={app.messages || []}
                currentUserId={currentUser?.id || ''}
                onSendMessage={handleSendMessage}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="rounded-lg bg-slate-800 p-2 text-slate-400 hover:bg-slate-700 hover:text-white transition-colors"
            title="Вернуться назад"
          >
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-3xl font-bold text-white">Панель Администратора</h1>
        </div>
        <div className="flex gap-2 rounded-lg bg-slate-900 p-1 border border-slate-800 self-start md:self-auto">
          <button
            onClick={() => setActiveTab('applications')}
            className={`flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-all ${
              activeTab === 'applications' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText size={16} />
            Заявки
          </button>
          <button
            onClick={() => setActiveTab('console')}
            className={`flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-all ${
              activeTab === 'console' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Terminal size={16} />
            Консоль
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-all ${
              activeTab === 'settings' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Settings size={16} />
            Настройки
          </button>
        </div>
      </div>

      {activeTab === 'applications' && (
        <div className="space-y-4">
          {applications.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              Нет новых заявок
            </div>
          ) : (
            applications.map((app) => (
              <motion.div
                key={app.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                onClick={() => setSelectedAppId(app.id)}
                className="group cursor-pointer rounded-xl bg-slate-900 p-6 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800/80 transition-all"
              >
                <div className="flex flex-col md:flex-row justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-lg font-bold text-white group-hover:text-indigo-400 transition-colors">{app.nickname}</h3>
                      <span className="text-sm text-slate-500">({app.discord})</span>
                      {app.messages?.length > 0 && (
                         <span className="flex items-center gap-1 text-xs bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full">
                           <MessageSquare size={10} />
                           {app.messages.length}
                         </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-slate-400">
                      <span className="bg-slate-800 px-2 py-0.5 rounded text-indigo-300 border border-slate-700">
                        {roles.find(r => r.id === app.roleId)?.title || app.roleId}
                      </span>
                      <span>•</span>
                      <span>{app.age} лет</span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock size={12} />
                        {new Date(app.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 self-start">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        app.status === 'approved' ? 'bg-green-500/10 text-green-500' : 
                        app.status === 'rejected' ? 'bg-red-500/10 text-red-500' :
                        app.status === 'interview' ? 'bg-yellow-500/10 text-yellow-500' :
                        'bg-slate-700 text-slate-300'
                    }`}>
                        {app.status === 'approved' ? 'Одобрено' : 
                         app.status === 'rejected' ? 'Отказано' : 
                         app.status === 'interview' ? 'Собеседование' : 'На рассмотрении'}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>
      )}

      {activeTab === 'console' && (
        <AdminConsole />
      )}

      {activeTab === 'settings' && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {roles.map((role) => {
            const isOpen = settings.openRoles.includes(role.id);
            return (
              <div key={role.id} className="flex items-center justify-between p-4 rounded-xl bg-slate-900 border border-slate-800">
                <div className="flex items-center gap-3">
                    <role.icon size={20} className="text-slate-400" />
                    <div>
                        <span className="font-medium text-white block">{role.title}</span>
                        {role.isHidden && (
                            <span className="text-[10px] font-bold text-red-400 bg-red-900/30 px-1.5 py-0.5 rounded border border-red-800/50 uppercase inline-block mt-0.5">
                                Secret
                            </span>
                        )}
                    </div>
                </div>
                <button
                  onClick={() => handleToggleRole(role.id)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    isOpen 
                      ? 'bg-green-500/10 text-green-500 hover:bg-green-500/20' 
                      : 'bg-red-500/10 text-red-500 hover:bg-red-500/20'
                  }`}
                >
                  {isOpen ? (
                    <>
                      <ToggleRight size={18} /> Открыто
                    </>
                  ) : (
                    <>
                      <ToggleLeft size={18} /> Закрыто
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
