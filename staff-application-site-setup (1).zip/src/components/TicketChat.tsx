import React, { useState, useRef, useEffect } from 'react';
import { Send, User as UserIcon, Shield } from 'lucide-react';
import { ChatMessage } from '../types';
import { cn } from '../utils/cn';

interface TicketChatProps {
  messages: ChatMessage[];
  currentUserId: string;
  onSendMessage: (text: string) => void;
  title: string;
}

export const TicketChat: React.FC<TicketChatProps> = ({ messages, currentUserId, onSendMessage, title }) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim()) {
      onSendMessage(inputText);
      setInputText('');
    }
  };

  return (
    <div className="flex h-[600px] flex-col rounded-xl bg-slate-900 border border-slate-800 overflow-hidden">
      <div className="border-b border-slate-800 bg-slate-900 p-4">
        <h3 className="font-bold text-white flex items-center gap-2">
          {title}
        </h3>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950/50">
        {messages.length === 0 ? (
          <div className="flex h-full items-center justify-center text-slate-500">
            <p>Начните диалог...</p>
          </div>
        ) : (
          messages.map((msg) => {
            const isMe = msg.senderId === currentUserId;
            return (
              <div
                key={msg.id}
                className={cn(
                  "flex w-full gap-2",
                  isMe ? "justify-end" : "justify-start"
                )}
              >
                {!isMe && (
                  <div className={`h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0 ${msg.isAdmin ? 'bg-indigo-600' : 'bg-slate-700'}`}>
                     {msg.isAdmin ? <Shield size={14} className="text-white" /> : <UserIcon size={14} className="text-white" />}
                  </div>
                )}
                
                <div
                  className={cn(
                    "max-w-[80%] rounded-2xl px-4 py-2 text-sm",
                    isMe
                      ? "bg-indigo-600 text-white rounded-tr-none"
                      : "bg-slate-800 text-slate-100 rounded-tl-none"
                  )}
                >
                  <div className="mb-1 text-xs opacity-70 flex justify-between gap-4">
                    <span className="font-bold">{msg.senderName}</span>
                    <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <p className="whitespace-pre-wrap break-words">{msg.content}</p>
                </div>

                {isMe && (
                  <div className={`h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0 ${msg.isAdmin ? 'bg-indigo-600' : 'bg-slate-700'}`}>
                    {msg.isAdmin ? <Shield size={14} className="text-white" /> : <UserIcon size={14} className="text-white" />}
                  </div>
                )}
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="border-t border-slate-800 bg-slate-900 p-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Введите сообщение..."
            className="flex-1 rounded-lg border border-slate-700 bg-slate-950 px-4 py-2 text-white outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 placeholder-slate-600"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="rounded-lg bg-indigo-600 p-2 text-white transition hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send size={20} />
          </button>
        </div>
      </form>
    </div>
  );
};
