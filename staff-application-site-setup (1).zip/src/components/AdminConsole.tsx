import React, { useState, useRef, useEffect } from 'react';
import { Terminal } from 'lucide-react';
import { storage } from '../lib/storage';
import { BlacklistType } from '../types';

interface LogEntry {
  id: string;
  type: 'info' | 'error' | 'success';
  text: string;
}

export const AdminConsole: React.FC = () => {
  const [input, setInput] = useState('');
  const [logs, setLogs] = useState<LogEntry[]>([
    { id: 'init', type: 'info', text: 'CapyWorld Admin Console v1.0 initialized. Type /help for commands.' }
  ]);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const addLog = (text: string, type: 'info' | 'error' | 'success' = 'info') => {
    setLogs(prev => [...prev, { id: Math.random().toString(), type, text }]);
  };

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = input.trim();
    if (!cmd) return;

    addLog(`> ${cmd}`, 'info');
    setInput('');

    const parts = cmd.split(' ');
    const command = parts[0].toLowerCase();
    const args = parts.slice(1);

    try {
      switch (command) {
        case '/help':
          addLog('Available commands:', 'info');
          addLog('  /ban <username> <type> <reason> - Add user to blacklist', 'info');
          addLog('  /unban <username> <type> - Remove user from blacklist', 'info');
          addLog('  /list - List all blacklisted users', 'info');
          addLog('  /clear - Clear console', 'info');
          addLog('  Types: CSA, CST, CSB, GLOBAL', 'info');
          break;

        case '/clear':
          setLogs([]);
          break;

        case '/list':
          const list = storage.getBlacklist();
          if (list.length === 0) {
            addLog('Blacklist is empty.', 'info');
          } else {
            addLog('Blacklisted Users:', 'info');
            list.forEach(item => {
              addLog(`- ${item.username} [${item.type}]: ${item.reason} (by ${item.issuedBy})`, 'info');
            });
          }
          break;

        case '/ban':
          if (args.length < 3) {
            addLog('Usage: /ban <username> <type> <reason>', 'error');
            break;
          }
          const [userToBan, typeStr, ...reasonParts] = args;
          const type = typeStr.toUpperCase() as BlacklistType;
          const reason = reasonParts.join(' ');
          const validTypes = ['CSA', 'CST', 'CSB', 'GLOBAL', 'OTHER'];

          if (!validTypes.includes(type)) {
             addLog(`Invalid type. Valid types: ${validTypes.join(', ')}`, 'error');
             break;
          }

          const currentUser = storage.getCurrentUser();
          storage.addToBlacklist({
            username: userToBan,
            type,
            reason,
            issuedBy: currentUser?.username || 'Console'
          });
          addLog(`Successfully blacklisted ${userToBan} as ${type}.`, 'success');
          break;

        case '/unban':
          if (args.length < 2) {
             addLog('Usage: /unban <username> <type>', 'error');
             break;
          }
          const [userToUnban, typeToUnbanStr] = args;
          storage.removeFromBlacklist(userToUnban, typeToUnbanStr.toUpperCase() as BlacklistType);
          addLog(`Removed ${userToUnban} from blacklist (${typeToUnbanStr}).`, 'success');
          break;

        default:
          addLog(`Unknown command: ${command}`, 'error');
      }
    } catch (err: any) {
      addLog(err.message, 'error');
    }
  };

  return (
    <div className="flex flex-col h-[500px] bg-slate-950 rounded-xl border border-slate-800 font-mono text-sm shadow-2xl overflow-hidden">
      <div className="bg-slate-900 px-4 py-2 border-b border-slate-800 flex items-center gap-2">
        <Terminal size={16} className="text-slate-400" />
        <span className="text-slate-400">root@capyworld-admin:~</span>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-1">
        {logs.map(log => (
          <div key={log.id} className={`${
            log.type === 'error' ? 'text-red-400' : 
            log.type === 'success' ? 'text-green-400' : 
            'text-slate-300'
          }`}>
            {log.text}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={handleCommand} className="bg-slate-900 p-2 border-t border-slate-800 flex items-center">
        <span className="text-green-500 mr-2">➜</span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="flex-1 bg-transparent text-white outline-none placeholder-slate-600"
          placeholder="Type command..."
          autoFocus
        />
      </form>
    </div>
  );
};
