import React from 'react';
import { LucideIcon, Lock } from 'lucide-react';
import { motion } from 'framer-motion';

interface RoleCardProps {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  color: string;
  onSelect: (id: string) => void;
  isSelected: boolean;
  isOpen?: boolean;
}

export const RoleCard: React.FC<RoleCardProps> = ({
  id,
  title,
  description,
  icon: Icon,
  color,
  onSelect,
  isSelected,
  isOpen = true,
}) => {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 20 },
        show: { opacity: 1, y: 0 }
      }}
      whileHover={isOpen ? { y: -5, scale: 1.02 } : {}}
      whileTap={isOpen ? { scale: 0.98 } : {}}
      className={`group relative overflow-hidden rounded-2xl border p-6 transition-all duration-300 ${
        !isOpen 
          ? 'cursor-not-allowed border-slate-800/50 bg-slate-900/20 opacity-60 grayscale'
          : isSelected
            ? 'cursor-pointer border-indigo-500/50 bg-indigo-500/10 shadow-lg shadow-indigo-500/10'
            : 'cursor-pointer border-slate-800/50 bg-slate-900/40 backdrop-blur-sm hover:border-indigo-500/30 hover:bg-slate-800/60 hover:shadow-2xl hover:shadow-indigo-500/10'
      }`}
      onClick={() => isOpen && onSelect(id)}
    >
      {/* Animated Gradient Border Effect */}
      {isOpen && (
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none">
             <div className="absolute inset-[-100%] bg-gradient-to-r from-transparent via-indigo-500/10 to-transparent rotate-45 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
        </div>
      )}
      {/* Glow effect on hover */}
      {isOpen && (
         <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-indigo-500/0 to-indigo-500/0 opacity-0 transition-opacity duration-500 group-hover:from-indigo-500/5 group-hover:to-purple-500/5 group-hover:opacity-100" />
      )}

      {!isOpen && (
        <div className="absolute right-4 top-4 rounded-full bg-slate-800/80 p-2 text-slate-400 backdrop-blur-sm">
          <Lock size={16} />
        </div>
      )}
      <div className={`relative mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl ${color} text-white shadow-lg shadow-black/20 ring-1 ring-white/10 transition-transform duration-500 group-hover:rotate-3 group-hover:scale-110`}>
        <Icon size={28} />
      </div>
      <h3 className="mb-2 text-xl font-bold text-white tracking-tight group-hover:text-indigo-200 transition-colors">{title}</h3>
      <p className="text-sm text-slate-400 leading-relaxed group-hover:text-slate-300 transition-colors">{description}</p>
      
      <div className={`mt-6 flex items-center justify-between`}>
         <div className={`text-sm font-medium transition-colors ${
          !isOpen ? 'text-red-400' : isSelected ? 'text-indigo-400' : 'text-slate-500 group-hover:text-indigo-400'
        }`}>
          {!isOpen ? 'Набор закрыт' : isSelected ? 'Выбрано' : 'Нажмите, чтобы выбрать'}
        </div>
        {isOpen && !isSelected && (
           <div className="h-6 w-6 rounded-full border border-slate-700 flex items-center justify-center text-slate-500 opacity-0 -translate-x-2 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-0 group-hover:border-indigo-500/50 group-hover:text-indigo-400">
              →
           </div>
        )}
      </div>
    </motion.div>
  );
};
