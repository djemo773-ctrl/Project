import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { Send, CheckCircle, Loader2, AlertCircle } from 'lucide-react';
import { storage } from '../lib/storage';
import { roles } from '../data/roles';

interface FormData {
  nickname: string;
  discord: string;
  age: number;
  about: string; // Keep as fallback
  portfolio: string;
  [key: string]: any; // For dynamic question answers
}

interface ApplicationFormProps {
  selectedRoleId: string;
  selectedRoleTitle: string;
  onBack: () => void;
}

export const ApplicationForm: React.FC<ApplicationFormProps> = ({ selectedRoleId, selectedRoleTitle, onBack }) => {
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const roleDef = roles.find(r => r.id === selectedRoleId);
  const questions = roleDef?.questions || [];

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    setSubmitError('');
    
    try {
      const currentUser = storage.getCurrentUser();
      
      if (!currentUser) {
        setSubmitError('Вы должны быть авторизованы');
        setIsSubmitting(false);
        return;
      }

      // Extract dynamic answers
      const answers: Record<string, string> = {};
      questions.forEach(q => {
        answers[q.id] = data[q.id];
      });

      // Simulate network delay
      await new Promise((resolve) => setTimeout(resolve, 1000));

      storage.createApplication({
        roleId: selectedRoleId,
        userId: currentUser.id,
        nickname: data.nickname,
        discord: data.discord,
        age: data.age,
        about: data.about || 'See answers', // Fallback
        portfolio: data.portfolio,
        answers: answers,
      });

      setIsSuccess(true);
    } catch (e: any) {
      console.error(e);
      setSubmitError('Ошибка при отправке: ' + (e.message || 'Unknown error'));
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center justify-center rounded-2xl bg-slate-900 p-8 text-center shadow-xl border border-slate-800"
      >
        <div className="mb-6 rounded-full bg-green-900/30 p-4">
          <CheckCircle className="h-12 w-12 text-green-500" />
        </div>
        <h2 className="mb-2 text-2xl font-bold text-white">Заявка отправлена!</h2>
        <p className="mb-8 text-slate-400">
          Мы получили вашу заявку на роль <span className="font-semibold text-indigo-400">{selectedRoleTitle}</span>. 
          Администрация свяжется с вами в Discord или через систему тикетов в ближайшее время.
        </p>
        <button
          onClick={onBack}
          className="rounded-lg bg-slate-800 px-6 py-3 font-semibold text-white transition hover:bg-slate-700 border border-slate-700"
        >
          Вернуться на главную
        </button>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl bg-slate-900 p-8 shadow-xl border border-slate-800"
    >
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white">Заполните анкету</h2>
        <p className="text-slate-400">Подаем заявку на роль: <span className="font-semibold text-indigo-400">{selectedRoleTitle}</span></p>
        <p className="mt-2 text-sm text-yellow-500/80 bg-yellow-900/10 border border-yellow-900/20 p-3 rounded-lg">
           Вам предстоит ответить на {questions.length} вопросов. Отвечайте честно и развернуто.
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Basic Info */}
        <div className="grid gap-6 md:grid-cols-2">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Никнейм</label>
            <input
              {...register('nickname', { required: 'Введите никнейм' })}
              className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-2.5 text-white outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 placeholder-slate-600"
              placeholder="Steve"
            />
            {errors.nickname && (
              <p className="flex items-center text-sm text-red-400"><AlertCircle size={14} className="mr-1"/> {errors.nickname.message as string}</p>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Discord</label>
            <input
              {...register('discord', { required: 'Введите Discord tag' })}
              className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-2.5 text-white outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 placeholder-slate-600"
              placeholder="user#0000"
            />
            {errors.discord && (
              <p className="flex items-center text-sm text-red-400"><AlertCircle size={14} className="mr-1"/> {errors.discord.message as string}</p>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-300">Возраст</label>
          <input
            type="number"
            {...register('age', { 
              required: 'Укажите возраст',
              min: { value: 12, message: 'Минимальный возраст 12 лет' },
              max: { value: 99, message: 'Укажите реальный возраст' }
            })}
            className="w-full md:w-1/3 rounded-lg border border-slate-700 bg-slate-950 px-4 py-2.5 text-white outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 placeholder-slate-600"
            placeholder="16"
          />
          {errors.age && (
            <p className="flex items-center text-sm text-red-400"><AlertCircle size={14} className="mr-1"/> {errors.age.message as string}</p>
          )}
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-300">Ссылка на портфолио (если есть)</label>
          <input
            {...register('portfolio')}
            className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-2.5 text-white outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 placeholder-slate-600"
            placeholder="https://imgur.com/..."
          />
        </div>

        <div className="my-6 border-t border-slate-800"></div>
        <h3 className="text-lg font-bold text-white mb-4">Вопросы для кандидата</h3>

        {/* Dynamic Questions */}
        {questions.map((q) => (
          <div key={q.id} className="space-y-2">
            <label className="text-sm font-medium text-slate-300 block">
              {q.text}
            </label>
            <textarea
              {...register(q.id, { required: 'Это поле обязательно' })}
              rows={3}
              className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-2.5 text-white outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 placeholder-slate-600"
              placeholder={q.placeholder}
            />
            {errors[q.id] && (
               <p className="flex items-center text-sm text-red-400"><AlertCircle size={14} className="mr-1"/> {errors[q.id]?.message as string}</p>
            )}
          </div>
        ))}

        {/* Fallback for legacy "about" if needed, usually covered by questions now */}
        <input type="hidden" {...register('about')} value="Detailed in questions" />

        {submitError && (
          <div className="flex items-center gap-2 rounded-lg bg-red-900/20 p-3 text-sm text-red-400 border border-red-900/30">
            <AlertCircle size={16} />
            {submitError}
          </div>
        )}

        <div className="flex gap-4 pt-4">
          <button
            type="button"
            onClick={onBack}
            className="w-full rounded-lg border border-slate-700 bg-transparent px-6 py-3 font-semibold text-slate-300 transition hover:bg-slate-800 hover:text-white"
          >
            Назад
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-indigo-600 px-6 py-3 font-semibold text-white transition hover:bg-indigo-700 disabled:bg-indigo-400"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="animate-spin" size={20} />
                Отправка...
              </>
            ) : (
              <>
                <Send size={20} />
                Отправить заявку
              </>
            )}
          </button>
        </div>
      </form>
    </motion.div>
  );
};
