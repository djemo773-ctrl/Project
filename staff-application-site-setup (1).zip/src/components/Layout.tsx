import React, { useEffect, useState } from 'react';
import { Server, User as UserIcon, LogOut, Shield } from 'lucide-react';
import { storage } from '../lib/storage';
import { User } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  user: User | null;
  onLogout: () => void;
  onAdminClick: () => void;
  onHomeClick: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, user, onLogout, onAdminClick, onHomeClick }) => {
  const [teamSize, setTeamSize] = useState(0);

  useEffect(() => {
    // Initial fetch
    setTeamSize(storage.getTeamSize());
    
    // Simple poll to keep stats updated (simulating realtime)
    const interval = setInterval(() => {
      setTeamSize(storage.getTeamSize());
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex min-h-screen flex-col bg-slate-950 font-sans text-slate-100 selection:bg-indigo-500/30 relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900/20 via-slate-950 to-slate-950 -z-10" />

      <header className="sticky top-0 z-20 border-b border-slate-800/50 bg-slate-950/70 backdrop-blur-xl transition-all duration-300">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-6">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={onHomeClick}>
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-indigo-700 text-white shadow-lg shadow-indigo-500/20 transition-all duration-300 group-hover:scale-105 group-hover:shadow-indigo-500/30">
              <Server size={24} />
            </div>
            <span className="text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">CapyWorld Staff</span>
          </div>
          
          <div className="flex items-center gap-6">
            {user && (
              <div className="flex items-center gap-4">
                {user.role === 'admin' && (
                  <button 
                    onClick={onAdminClick}
                    className="flex items-center gap-2 text-sm font-medium text-indigo-400 hover:text-indigo-300 transition-colors duration-200"
                  >
                    <Shield size={16} />
                    <span className="hidden md:inline">Админка</span>
                  </button>
                )}
                <div className="flex items-center gap-2 text-sm text-slate-300 bg-slate-900/50 px-3 py-1.5 rounded-full border border-slate-800/50">
                  <UserIcon size={16} />
                  <span>{user.username}</span>
                </div>
                <button 
                  onClick={onLogout}
                  className="text-slate-500 hover:text-red-400 transition-colors duration-200 p-2 hover:bg-slate-800/50 rounded-lg"
                  title="Выйти"
                >
                  <LogOut size={18} />
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="flex-grow px-6 py-12 relative z-10">
        <div className="mx-auto max-w-5xl">
          {children}
        </div>
      </main>

      <footer className="border-t border-slate-800/50 bg-slate-950/50 backdrop-blur-sm py-12 mt-auto">
        <div className="mx-auto max-w-5xl px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-8 text-center md:text-left">
            <div className="space-y-4">
              <h4 className="font-bold text-white text-lg">Статистика</h4>
              <div className="space-y-2">
                <div className="flex items-center justify-center md:justify-start gap-2 text-sm text-slate-400">
                  <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                  В команде: <span className="text-white font-medium">{teamSize} чел.</span>
                </div>
                <div className="flex items-center justify-center md:justify-start gap-2 text-sm text-slate-400">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  Время ответа: <span className="text-white font-medium">~5 дней</span>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <h4 className="font-bold text-white text-lg">О нас</h4>
              <p className="text-sm text-slate-400 leading-relaxed">
                CapyWorld — это увлекательный Minecraft сервер выживания. У нас вы найдете сбалансированную экономику, 
                дружное комьюнити и справедливую администрацию. Стройте, выживайте и находите новых друзей!
              </p>
            </div>
            <div className="space-y-4">
              <h4 className="font-bold text-white text-lg">Контакты</h4>
              <a href="#" className="block text-sm text-slate-400 hover:text-indigo-400 transition-colors duration-200">
                Discord: discord.gg/capyworld
              </a>
              <a href="#" className="block text-sm text-slate-400 hover:text-indigo-400 transition-colors duration-200">
                Email: support@capyworld.net
              </a>
            </div>
          </div>
          <div className="text-center text-sm text-slate-600 border-t border-slate-800/50 pt-8 mt-8">
            <p>&copy; {new Date().getFullYear()} CapyWorld. Все права защищены.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};
