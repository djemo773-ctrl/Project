export type UserRole = 'user' | 'admin';

export interface User {
  id: string;
  username: string;
  password?: string;
  role: UserRole;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: number;
  isAdmin: boolean;
}

export interface Application {
  id: string;
  roleId: string;
  userId: string;
  nickname: string;
  discord: string;
  age: number;
  about: string; // Legacy field, kept for compatibility
  portfolio: string;
  answers: Record<string, string>; // Question ID -> Answer
  status: 'pending' | 'interview' | 'approved' | 'rejected';
  createdAt: number;
  messages: ChatMessage[];
}

export interface SiteSettings {
  openRoles: string[]; // List of Role IDs that are open
}

export type BlacklistType = 'CSA' | 'CST' | 'CSB' | 'GLOBAL' | 'OTHER';

export interface BlacklistEntry {
  id: string;
  username: string; // The username blocked
  type: BlacklistType;
  reason: string;
  issuedBy: string;
  createdAt: number;
}
